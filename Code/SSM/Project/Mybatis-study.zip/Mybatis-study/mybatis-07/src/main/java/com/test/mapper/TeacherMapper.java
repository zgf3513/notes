package com.test.mapper;

import com.test.entity.Teacher;

public interface TeacherMapper {
    Teacher getTeacherAndStu(int id);
    Teacher getTeacherAndStu2(int id);
}
