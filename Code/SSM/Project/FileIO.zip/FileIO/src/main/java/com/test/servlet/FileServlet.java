package com.test.servlet;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.ProgressListener;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.UUID;

@WebServlet(name = "FileServlet", urlPatterns = "/upload.do")
public class FileServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 判断上传的文件是普通表单还是带文件的表单
        if (!ServletFileUpload.isMultipartContent(req)) {
            return;// 方法终止，说明是普通表单
        }
        try {
            // 创建文件的保存路径，建议在WEB-INF路径下，用户无法访问
            String realPath = this.getServletContext().getRealPath("/WEB-INF/images");
            File file = new File(realPath);
            if (!file.exists()) {
                file.mkdir();// 创建目录
            }
            // 缓存，临时文件
            // 临时路径，如果文件超过预期大小，过几天自动删除或通知用户转存为永久
            String tmpPath = this.getServletContext().getRealPath("/WEB-INF/tmp");
            File tmpFile = new File(tmpPath);
            if (!tmpFile.exists()) {
                tmpFile.mkdir();// 创建目录
            }
            // 处理上传的文件，使用Apache的文件上传组件来实现：common-FileUpload，依赖于common-io组件

            // 1.创建DiskFileItemFactory对象，处理文件上传路径或者大小限制
            DiskFileItemFactory factory = new DiskFileItemFactory();
            // 通过这个工厂设置一个缓冲区，当上传的文件大于这个缓冲区的时候将他放到临时文件中
            factory.setSizeThreshold(1024 * 1024);// 缓存区大小为1MB
            factory.setRepository(tmpFile);// 临时目录的保存目录，需要一个file

            // 2.获取ServletFileUpload
            ServletFileUpload upload = new ServletFileUpload(factory);

            // 监听文件上传进度
            upload.setProgressListener(new ProgressListener() {
                @Override
                public void update(long l, long l1, int i) {
                    System.out.println("总大小：" + l1 + "已上传" + l);
                }
            });

            // 处理乱码问题
            upload.setHeaderEncoding("UTF-8");
            // 设置文件的最大值
            upload.setFileSizeMax(1024 * 1024 * 10);
            // 设置总共能够上传文件的大小
            upload.setSizeMax(1024 * 1024 * 10);

            // 处理上传文件

            // 把前端请求封装成一个fileItem对象
            List<FileItem> fileItemList = upload.parseRequest(req);

            for (FileItem fileItem : fileItemList) {
                // 判断控件是否带文件
                if (fileItem.isFormField()) {
                    // getFieldName是前端表单控件的name值
                    String name = fileItem.getFieldName();
                    String value = fileItem.getString("UTF-8");// 处理乱码
                    System.out.println(name + ":" + value);
                }else {//文件
                    // 处理文件
                    String uploadFileName = fileItem.getName();
                    // 可能存在文件名不合法的情况
                    if (uploadFileName.trim().equals("") || uploadFileName==null){
                        continue;
                    }
                    // 获取上传的文件名
                    String fileName = uploadFileName;
                    // 获得文件的后缀名
                    String fileExtName = uploadFileName.substring(uploadFileName.lastIndexOf(".")+1);
                    /*
                    * 如果后缀名不合法，直接return
                    * */
                    // 网络传输中的东西都需要序列化，实体类如果想要在多个电脑上运行，需要传输==》需要把对象都序列化
                    // JNI=Java Native Interface
                    // Serializable：标记接口，JVM--->本地方法栈 native -->C++
                    String uuidPath = UUID.randomUUID().toString();
                    // 存放地址
                    // 文件真实存在的路径
                    String uploadPath = realPath+"/"+uuidPath;
                    // 给每个文件创建一个对应的文件夹
                    File uploadFile = new File(uploadPath);
                    if (!uploadFile.exists()){
                        uploadFile.mkdir();
                    }
                    // 文件传输
                    // 获取文件流
                    InputStream inputStream = fileItem.getInputStream();
                    // 创建一个文件输出流
                    FileOutputStream fos = new FileOutputStream(uploadFile+"/"+fileName);
                    // 创建缓冲区
                    byte[] buffer = new byte[1024*1024];
                    // 判断是否读取完毕
                    int len = 0;
                    // 如果大于0，说明还存在数据
                    while ((len=inputStream.read(buffer))>0){
                        fos.write(buffer,0,len);
                    }
                    // 关闭流
                    fos.close();
                    inputStream.close();

                    String msg = "上传成功";
                    System.out.println(msg);
                    // 清除临时文件
                    inputStream.close();
                }
            }
        } catch (FileUploadException e) {
            e.printStackTrace();
        }

    }
}
