package com.test.service;

public interface UserService {
    void getUser();
}
