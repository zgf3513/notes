package com.test.entity;

public class Cat {
    public void shout(){
        System.out.println("喵");
    }
}
