package com.test.mapper;

import com.test.entity.Student;

import java.util.List;

public interface StudentMapper {
    List<Student> getAllStuAndTeacher();
    List<Student> getAllStuAndTeacher2();
}
