package com.test.dao;

public interface UserDao {
    void getUser();
}
