import com.zgf.entity.Books;
import com.zgf.service.BooksService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class MyTest {
    @Autowired
    private BooksService booksService;
    @Test
    public void MyTest(){
        List<Books> all = booksService.getAll();
        for (Books books : all) {
            System.out.println(books);
        }
    }
}
