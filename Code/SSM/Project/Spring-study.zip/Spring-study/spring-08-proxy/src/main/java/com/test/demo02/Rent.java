package com.test.demo02;

// 租房
public interface Rent {
    void rent();
}
