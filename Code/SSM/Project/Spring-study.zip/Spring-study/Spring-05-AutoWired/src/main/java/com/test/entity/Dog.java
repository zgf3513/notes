package com.test.entity;

public class Dog {
    public void shout(){
        System.out.println("汪");
    }
}
