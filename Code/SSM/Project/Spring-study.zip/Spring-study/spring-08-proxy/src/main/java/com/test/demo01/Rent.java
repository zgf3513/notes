package com.test.demo01;

// 租房
public interface Rent {
    void rent();
}
